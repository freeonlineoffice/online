t.equal(require('aaa'), 'AX');
t.equal(require('bbb'), 'BY');
t.equal(require('ccc'), 'CX');
