module.exports = function() {
 console.log("a b")
};
