console.log('b');

try { require('./vendor/y.js') }
catch (err) { console.log('!y') }

