ex(require('./invalid.json'));
ex(require('./invalid'));
