export declare const fromCodePoint: (...codePoints: number[]) => string;
export declare function replaceCodePoint(codePoint: number): number;
export default function decodeCodePoint(codePoint: number): string;
//# sourceMappingURL=decode_codepoint.d.ts.map