console.log([
  __dirname,
  __filename,
  typeof process,
  typeof global,
  typeof Buffer
]);
