declare module "known-css-properties" {
  export const all: string[];
}
