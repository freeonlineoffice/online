# Documentation

- [API Reference](https://github.com/JoshGlazebrook/socks#api-reference)

- [Code Examples](./examples/index.md)