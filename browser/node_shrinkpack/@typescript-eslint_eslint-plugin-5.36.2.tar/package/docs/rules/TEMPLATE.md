> 🛑 This file is source code, not the primary documentation location! 🛑
>
> See **https://typescript-eslint.io/rules/your-rule-name** for documentation.

## Rule Details

To fill out: tell us more about this rule.

<!--tabs-->

### ❌ Incorrect

```ts
// To fill out: incorrect code
```

### ✅ Correct

```ts
// To fill out: correct code
```

## When Not To Use It

To fill out: why wouldn't you want to use this rule?
For example if this rule requires a feature released in a certain TS version.
