# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2022-09-22

### Commits

- Initial implementation, tests, readme [`0273e9f`](https://github.com/ljharb/safe-regex-test/commit/0273e9f96f4b09df413523f4faacc8ae9ac5e6cb)
- Initial commit [`b6c1edf`](https://github.com/ljharb/safe-regex-test/commit/b6c1edf740e6105fb71c34c1c69fadd837e8f7ab)
- npm init [`c7f5765`](https://github.com/ljharb/safe-regex-test/commit/c7f576580607b16458b5a16e6bfa3b639e49c6bd)
- Only apps should have lockfiles [`1162bf0`](https://github.com/ljharb/safe-regex-test/commit/1162bf011835040f7e2c9936734294b2d98536bf)
